package com.shop.service;

public interface CartService {

}
