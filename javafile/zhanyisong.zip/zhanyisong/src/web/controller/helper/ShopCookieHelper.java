package web.controller.helper;

import web.util.CookieUtil;

public class ShopCookieHelper extends CookieUtil{

	
}
